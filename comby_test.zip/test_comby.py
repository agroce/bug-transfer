from comby import Comby
import sys
comby = Comby()

def sub_and_print(source, lhs, rhs):
    
    #print(f"Original Source:\n{source}")
    i=0
    for match in comby.matches(source, lhs, language=".py"):
        environment = dict()
        mutant = ""
        for entry in match.environment:
            environment[entry] = match.environment.get(entry).fragment
        mutant = comby.substitute(rhs, environment)
        subRange = (match.location.start.offset, match.location.stop.offset)
        i += 1
        print(f"{i}. Subbed For:\n{source[subRange[0]:subRange[1]]}")
        print(f"Comby Output:\n{mutant}\n")



#print("Run python3 test_comby.py <flag>")
#print("Flag 1: Mutating Strings on large source, Flag 2: Mutating Strings on small source, Flag 3: Mutating on source with only ASCII chars, Flag 4: Mutating on source having non-ASCII chars")

source = []
source_file_name = 'inferenceutils.py'
lhs = '":[str]"'
rhs = '""'
flag = int(sys.argv[1])
if flag == 1:
    source_file_name = 'inferenceutils.py'
elif flag == 2:
    source_file_name = 'inferenceutils_trimmed.py'
elif flag == 3:
    source_file_name = 'source_with_ascii.py'
    lhs = ':[spaces~[ \t]*]:[a]:[newline~[\n]]'
    rhs = ':[spaces]:[a]:[newline]:[spaces]break;:[newline]'
elif flag == 4:
    source_file_name = 'source_with_non_ascii.py'    
    lhs = ':[spaces~[ \t]*]:[a]:[newline~[\n]]'
    rhs = ':[spaces]:[a]:[newline]:[spaces]break;:[newline]'

with open(source_file_name, 'r') as file:
    for l in file:
        source.append(l)

contents = ''.join(source)
print(contents)
print("______________________________________")
#print(flag)
#print(source_file_name)

sub_and_print(source= contents,
     lhs= lhs,
     rhs= rhs)