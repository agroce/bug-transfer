#
# DeepLabCut Toolbox (deeplabcut.org)
# A. & M.W. Mathis Labs
# https://github.com/DeepLabCut/DeepLabCut
#

def fun(a):
    x = a + 5
    print(x)